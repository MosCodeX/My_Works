<?php

if ($APP->lang=='en'){
$array['template'] = 'mapreg-en-2.tpl';

}
else if ($APP->lang=='ru'){
$array['template'] = 'mapreg-ru-2.tpl';
}
else
{
$array['template'] = 'mapreg-am-2.tpl';
}
?>