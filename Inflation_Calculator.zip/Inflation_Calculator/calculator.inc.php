<?php
	
if ($APP->lang=='en'){
$array['template'] = 'calculator-en.tpl';

}
else if ($APP->lang=='ru'){
$array['template'] = 'calculator-ru.tpl';
}
else
{
$array['template'] = 'calculator-am.tpl';
}

/*
$array['years_list'] = Date::getYearList2(1993, 2007);
$array['year_list'] = Date::getYearList2(1993, 2007);
$array['trad_country_list'] = BL::getEntityList('TradCountry', $APP->lang, 1);
$array['monthn_list'] = Date::getMonthListTrade("TP", $APP->date_i18n);

$now = new Date();
$array['years'] = (!is_null($APP->httpVar1('years'))) ? $APP->httpVar1('years') : NULL;
$array['thid'] = (!is_null($APP->httpVar1('thid'))) ? $APP->httpVar1('thid') : NULL;
$array['monid'] = (!is_null($APP->httpVar1('monid'))) ? $APP->httpVar1('monid') : NULL;
$array['year'] = (!is_null($APP->httpVar1('year'))) ? $APP->httpVar1('year') : NULL;
$array['nid'] = (!is_null($APP->httpVar1('nid'))) ? $APP->httpVar1('nid') : NULL;
$array['title'] = $APP->dic['trade'];
/*echo "<script>alert($array['thid'][0])</script>";
$array1['country'] = $APP->dic['country'];
$array1['year'] = $APP->dic['year'];
$array1['period'] = $APP->dic['period'];
$array1['a_1'] = $APP->dic['a_1'];
$array1['a_2'] = $APP->dic['a_2'];
$array1['a_3'] = $APP->dic['a_3'];
// for 2 list box...
$myarray=array();
if(!is_null($APP->httpVar1('year')))
{
    foreach($array['year'] as $key=>$value)
    {
        $myarray[]=$value;
    }
}
else
    $myarray[0]=NULL; //...for 2 list box

//for 3 list box...
$myarray1=array();
if(!is_null($APP->httpVar1('thid')))
{
    foreach($array['thid'] as $key=>$value)
    {
        $myarray1[]=$value;
    }
}
else
    $myarray1[0]=NULL; //...for 3 list box

//***new   for 4 list box...
$myarray2=array();
if(!is_null($APP->httpVar1('years')))
{
    foreach($array['years'] as $key=>$value)
    {
        $myarray2[]=$value;
    }
}
else
    $myarray2[0]=NULL;

$myarray3=array();

if(!is_null($APP->httpVar1('monid')))
{
    foreach($array['monid'] as $key=>$value)
    {
        $myarray3[]=$value;
    }
}
else
    $myarray3[0]=NULL; // //******new  for 4 list box...



if (is_null($myarray[0]) AND is_null($myarray2[0]) AND is_null($myarray1[0]) AND is_null($array['monid']))
{
    $array['null']=1;
}
else
{
// Browse
    $sql = "SELECT * , ROUND(a_1,1) AS s_1, ROUND(a_2,1) AS s_2, ROUND(a_3,1) AS s_3, ROUND(a_4,1) AS s_4, `title_{$APP->lang}` AS `title` FROM `trad` WHERE ";
// for 1 list box..month

    $sql .= (((is_numeric($myarray1[0]) && $myarray1[0] < 1) || is_null($myarray1[0]))  && is_null($myarray[0]) && is_null($myarray2[0]) && is_null($myarray3[0])) ? "1"  : "";
    if (is_numeric($myarray[0]) && $myarray[0] > 0 && is_numeric($myarray3[0]) && $myarray3[0] > 0)
    {
        $sql .= "(`monthn_id` = ".$myarray3[0]." ";
    }
    else if(is_numeric($myarray[0]) && $myarray[0] > 0 && !isset($myarray3[0]))
    {
        //$sql .= "(`monthn_id` = 1 OR `monthn_id` = 2 OR `monthn_id` = 3 OR `monthn_id` = 4 OR `monthn_id` = 5 OR `monthn_id` = 6 OR `monthn_id` = 7 OR `monthn_id` = 8 OR `monthn_id` = 9 OR `monthn_id` = 10 OR `monthn_id` = 11 OR `monthn_id` = 12 ) ";

        $sql .= "(`monthn_id` IN (1,2,3,4,5,6,7,8,9,10,11,12))";
    }
    else if(is_numeric($myarray3[0]) && $myarray3[0] > 0 && !isset($myarray[0]))
    {
        $sql .= "(`monthn_id` = ".$myarray3[0]." ";
    }
    $cnt3 = count($myarray3);
    if($cnt3>1)
    {
        for($i=1;$i<$cnt3;$i++){
            $sql .= (is_numeric($myarray[0]) && $myarray[0] > 0) ? " or `monthn_id` = ".$myarray3[$i]." " : "";
            $sql .= (is_numeric($myarray3[0]) && $myarray3[0] > 0) ? " or `monthn_id` = ".$myarray3[$i]." " : "";}
    }
    $sql .= (is_numeric($myarray[0]) && $myarray[0] && is_numeric($myarray3[0]) && $myarray3[0] > 0) ? ") " : "";
    $sql .= (is_numeric($myarray3[0]) && $myarray3[0] > 0 && !isset($myarray[0])) ? ") " : "";
//////////////////////////////
    $sql .= ((is_numeric($myarray3[0]) && $myarray3[0]> 0) && (is_numeric($myarray1[0]) && $myarray1[0]> 0)) ? "AND (`trad_country_id` = ".$myarray1[0]." " : "";
    $cnt1=count($myarray1);
    if($cnt1>1)
    {
        for($i=1;$i<$cnt1;$i++)
            $sql.=(is_numeric($myarray3[0]) && $myarray3[0] > 0) ? " or `trad_country_id` = ".$myarray1[$i]." " : "";//---------------------
    }
    $sql .= ((is_numeric($myarray3[0]) && $myarray3[0]> 0) && (is_numeric($myarray1[0]) && $myarray1[0]> 0))  ? ") " : "";


// for 2 list box...year
    $sql .= (is_numeric($myarray[0]) && $myarray[0] > 0) ? "AND (`date` = ".$myarray[0]." " : "";
    $cnt=count($myarray);
    if($cnt>1)
    {
        for($i=1;$i<$cnt;$i++)
            $sql.=" or `date` = ".$myarray[$i];
    }
    $sql .= (is_numeric($myarray[0]) && $myarray[0]> 0) ? ") " : "";
//...for 2 list box
//for 3 list box...country
    $sql .= ((is_numeric($myarray[0]) && $myarray[0]> 0) && (is_numeric($myarray1[0]) && $myarray1[0]> 0)) ? "AND (`trad_country_id` = ".$myarray1[0]." " : "";
    $cnt1=count($myarray1);
    if($cnt1>1)
    {
        for($i=1;$i<$cnt1;$i++)
            $sql .= (is_numeric($myarray[0]) && $myarray[0] > 0) ? " or `trad_country_id` = ".$myarray1[$i]   : "";
    }
    $sql .= ((is_numeric($myarray[0]) && $myarray[0] > 0) && (is_numeric($myarray1[0]) && $myarray1[0]> 0)) ? ") " : "";  //...for 3 list box

// for 4 list box...years (2) month=12 
    $sql .= ((is_numeric($myarray[0]) && $myarray[0] > 0) && (is_numeric($myarray2[0]) && $myarray2[0]> 0)) || ((is_numeric($myarray[0]) && $myarray[0] > 0) && (is_numeric($myarray2[0]) && $myarray2[0]> 0)) || ((is_numeric($myarray1[0]) && $myarray1[0] > 0) && (is_numeric($myarray2[0]) && $myarray2[0]> 0)&& (is_numeric($myarray3[0]) && $myarray3[0]> 0)) ? "OR" : "";
    $sql .= (is_numeric($myarray2[0]) && $myarray2[0] > 0) ? " (`monthn_id`=13) " : "";
    $sql .= (is_numeric($myarray2[0]) && $myarray2[0] > 0) ? "AND (`date` = ".$myarray2[0]." " : "";
    $cnt2=count($myarray2);
    if($cnt2>1)
    {
        for($i=1;$i<$cnt2;$i++)
            $sql.=" or `date` = ".$myarray2[$i];
    }
    $sql .= (is_numeric($myarray2[0]) && $myarray2[0]> 0) ? ") " : ""; //...for 4 list box
//for 3 list box...country
    $sql .= ((is_numeric($myarray2[0]) && $myarray2[0]> 0) && (is_numeric($myarray1[0]) && $myarray1[0]> 0)) ? "AND (`trad_country_id` = ".$myarray1[0]." " : "";
    $cnt1=count($myarray1);
    if($cnt1>1)
    {
        for($i=1;$i<$cnt1;$i++)
            $sql.=(is_numeric($myarray2[0]) && $myarray2[0] > 0) ? " or `trad_country_id` = ".$myarray1[$i]." " : "";//---------------------
    }
    $sql .= ((is_numeric($myarray2[0]) && $myarray2[0]> 0) && (is_numeric($myarray1[0]) && $myarray1[0]> 0))  ? ") " : "";
//...for 3 list box

    ///////////////////+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    if (is_null($myarray[0]) && is_null($myarray2[0]) && is_null($myarray3[0]))
    {
        $sql .= (is_numeric($myarray1[0]) && $myarray1[0] > 0)  ? " (`trad_country_id` = ".$myarray1[0]." " : "";
        $cnt1=count($myarray1);
        if($cnt1>1)
        {
            for($i=1;$i<$cnt1;$i++)
                $sql.=(is_numeric($myarray1[0]) && $myarray1[0] > 0) ? " or `trad_country_id` = ".$myarray1[$i]." " : "";//---------------------
        }
        $sql .= (is_numeric($myarray1[0]) && $myarray1[0]> 0) ? ") " : "";
    }
////////////////////+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    $sql .= " ORDER BY `trad_country_id`, `date` DESC, `monthn_id` ASC  ";
    $sqlexcel = $sql;
    $url = $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];

   $offset = (is_numeric($APP->httpVar1('offset')))? $APP->httpVar1('offset') : 0;
    $portion = 25;
    $array['portions'] = $APP->getPortions2($sql, $url, $portion, $offset);
    $sql .= " LIMIT ".$offset * $portion.", ".$portion;

    $array['trads'] = DBW::getArrayOfAssoc3($sql);
 

//////////////excel file maker////////////////

    if (!is_null($APP->httpVar1('submit')))
    {
        $records = DBW::numRows($sqlexcel);
        $l = 0;
        $excel=new ExcelWriter("../myXls.xls");
        $myArr= array("$array1[country]","$array1[year]","$array1[period]","$array1[a_1]","$array1[a_2]","$array1[a_3]");
        $excel->writeLine($myArr);
        do
        {
            $records -= $portion*100;
            $sqlexcel .= " LIMIT ".$portion*100*$l.", ".$portion*100;
            $l++;
            $array['tradsexcel'] = DBW::getArrayOfAssoc3($sqlexcel);
            $sqlexcel = substr($sqlexcel, 0,strpos($sqlexcel, "LIMIT"));
            foreach($array['tradsexcel'] as $value)
            {
                $myArr= array("$value[title]","$value[date]","$value[monthn_id]","$value[a_1]","$value[a_2]","$value[a_3]");
                $excel->writeLine($myArr);
            }

        }
        while($records > $portion*100);
        $excel->close();
    }
}
$row = 1;
if (($handle = fopen("Calculator2.csv", "r")) !== FALSE) {
  while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    $num = count($data);
    echo "<p> $num fields in line $row: <br /></p>\n";
    $row++;
    for ($c=0; $c < $num; $c++) {
        echo $data[$c] . "<br />\n";
    }
  }
  fclose($handle);
}

?>

<!--// News releases
	$array['news_releases'] = BL::getNewsTitles(5);

		
	
	// Press Releases
	//$array['press_releases'] = BL::getNewsTitles(3, 4);
	
	// Events
	$array['events'] = BL::getNewsTitles(6, 5);
	
	// Publications
	$array['publications'] = BL::getHomePublications(6);

	// Latest Indicators Timetable
	// defining last year and month filled
	$r = BL::getLastTimetableDate();	
	$year = $array['year'] = $r['year'];
	$month = $array['month'] = $r['month'];
		
	// Getting all records for main indicators for the month
	$sql = "SELECT t.*, i.id AS `id`, i.title_{$APP->lang} AS `title` FROM `indicator_timetable` AS `t` ";
	$sql .= "LEFT JOIN `indicator` AS `i` ON i.id = t.indicator_id ";
	$sql .= "WHERE i.on_home = 1 AND t.year = {$year} AND t.month = {$month} AND i.period=0 ";
	$sql .= "ORDER BY i.ord ";
	
	$array['indicators'] = DBW::getArrayOfAssoc($sql);
	$dd = &$APP->date_i18n;
	//******************************************************
	$res_gross = BL::getLastTimetableGrossDate();	
	$year_gross = $array['year'] = $res_gross['year'];
	$month_gross = $array['month'] = $res_gross['month'];
	// Getting gross records for main page
	$sql = "SELECT t.*, i.id AS `id`, i.title_{$APP->lang} AS `title` FROM `indicator_timetable` AS `t` ";
	$sql .= "LEFT JOIN `indicator` AS `i` ON i.id = t.indicator_id ";
	$sql .= "WHERE i.on_home = 1 AND t.year = {$year_gross} AND i.period=1 ";
	$sql .= ($month == '13') ? "AND t.month = {$month_gross}-'1' " : "AND t.month = {$month_gross} ";
	$sql .= "ORDER BY i.ord ";
	$array['gross'] = DBW::getArrayOfAssoc($sql); 
	// Table Labels
	$array['label1'] = $dd['M'][$month].' '.$year; //Èçìåíåíèÿ 25 ôåâðàëÿ 2011
	$month_gross=='13' ? $array['label_gross1'] = $dd['K'][$month_gross-1].' '.$year_gross :$array['label_gross1'] = $dd['K'][$month_gross].' '.$year_gross;
	
	$id = $array['id'] = $APP->httpVar('id');
	$sql = "SELECT t.*, i.id AS '01001', t.month AS `month`, i.title_{$APP->lang} AS `title`, i.is_main AS `is_main` FROM `indicator_timetable` AS `t` ";
	$sql .= "LEFT JOIN `indicator` AS `i` ON i.id = t.indicator_id  WHERE `id`='01001' ";
	$sql .= "AND i.id = '01001' ";
	$sql .= "AND t.month = '13' ";
	$sql .= "ORDER BY t.year ASC";
	$result = mysql_query($sql); 
	@$array['ttitle'] = mysql_result($result,0,4);
	$array['timetable'] = DBW::getArrayOfAssoc($sql);
?>
*/
