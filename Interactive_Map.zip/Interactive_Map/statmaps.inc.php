<?php

if ($APP->lang=='en'){
$array['template'] = 'statmaps-en.tpl';

}
else if ($APP->lang=='ru'){
$array['template'] = 'statmaps-ru.tpl';
}
else
{
$array['template'] = 'statmaps-am.tpl';
}
?>