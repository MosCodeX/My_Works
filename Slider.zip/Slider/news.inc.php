<?php

// Checking if show Open news or not
$id = $APP->httpVar('id');

if(is_numeric($id)) {
	// Showing Open News
	$issue = new Issue($id, $APP->lang);
	
	if($issue->exists()) {
		$type = $issue->getIssueType($APP->lang);
		$array['issue'] = &$issue;
		$array['type'] = &$type;
		$array['images'] = File::getEntityFiles('Issue', $id, 'img', 'm');
		$array['template'] = 'news_open.tpl';
		
		$array['title'] = $type->_title;
		
		// Checking if Issue is a just a file
		If($issue->is_file > 0) {
			// Get first Document file
			$docs = File::getEntityFiles('Issue', $id, 'doc');
			$fid = $docs[0]->file->id;
			
			$APP->Redirect('../open.php?fid='.$fid);
			exit;	
		}
	} else {
	 	$APP->Redirect('./');
	}

} elseif((intval($nid) == 134 || intval($nid) == 135 || intval($nid) == 136) && !strlen($id)) {

	$type_id = $page->module_id;
	echo($type_id);
	
	$type = new IssueType($type_id, $APP->lang);
	
	if(!$type->exists()) $APP->Redirect('./');
	
	$array['template'] = 'news.tpl';
	$array['base_url'] = './?nid='.$APP->httpVar('nid');
	
	$portion = $APP->config['news_portion'];
	$offset =(is_numeric($APP->httpVar('offset'))) ? $APP->httpVar('offset') : 0;
	$year  = (is_numeric($APP->httpVar('year'))) ? $APP->httpVar('year') : NULL;
	$month = (is_numeric($APP->httpVar('month'))) ? $APP->httpVar('month') : NULL;
	$q = $APP->httpVar('q');
	
	$sql = "SELECT `id`, `date`, `title_{$APP->lang}` AS `title`, `short_{$APP->lang}` AS `short` ";
	
	if($q) {
		$sql .= ", MATCH(`title_{$APP->lang}`, `short_{$APP->lang}`, `text_{$APP->lang}`) AGAINST ('".DBW::escape($q)."') AS `score` ";
	}
	
	$sql .= "FROM `issue` ";
	$sql .= "WHERE `issue_type_id` = {$type->id} ";
	
	// By Date
	$sql .= ($year) ? "AND YEAR(`date`) = {$year} " : "";
	$sql .= ($month) ? "AND MONTH(`date`) = {$month} " : "";
	
	// Fulletext Search
	if($q) {
		$sql .= "AND MATCH(`title_{$APP->lang}`, `short_{$APP->lang}`, `text_{$APP->lang}`) AGAINST ('".DBW::escape($q)."') ";
	}
	
	$url = $array['base_url'];
	$url .= ($year) ? "&amp;year={$year}" : "";
	$url .= ($month) ? "&amp;month={$month}" : "";
	$array['portions'] = $APP->getPortions($sql, $url, $portion, $offset);
	
	if($q) {
		$sql .= "ORDER BY  `score` ASC, `id` DESC, `date` DESC ";
	} else {
		$sql .= "ORDER BY  `date` DESC, `id` DESC ";
	}

	$sql .= "LIMIT ".$offset*$portion.", ".$portion;
	
	$array['q'] = $APP->httpVar('q');
	$array['nid'] = $APP->httpVar('nid');
	$array['month_list'] = Date::getMonthListI18N('F', $APP->date_i18n);
	$array['year_list'] = Date::getYearList(2005);
	$array['month'] = $month;
	$array['year'] = $year;
	$array['type'] = &$type;
	$array['news'] = DBW::getArrayOfAssoc($sql);

}
?>
