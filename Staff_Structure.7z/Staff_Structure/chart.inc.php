
<?php

if ($APP->lang=='en'){
$array['template'] = 'chart-en.tpl';

}
else if ($APP->lang=='ru'){
$array['template'] = 'chart-ru.tpl';
}
else
{
$array['template'] = 'chart-am.tpl';
}
?>