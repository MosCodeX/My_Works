<?php
	$array['template'] = 'home.tpl';
	
	// News releases
	$array['news_releases'] = BL::getNewsTitles(5);

		
	
	// Press Releases
	//$array['press_releases'] = BL::getNewsTitles(3, 4);
	
	// Events
	$array['events'] = BL::getNewsTitles(6, 5);
	
	// Publications
	$array['publications'] = BL::getHomePublications(6);

	// Latest Indicators Timetable
	// defining last year and month filled
	$r = BL::getLastTimetableDate();	
	$year = $array['year'] = $r['year'];
	$month = $array['month'] = $r['month'];
		
	// Getting all records for main indicators for the month
	$sql = "SELECT t.*, i.id AS `id`, i.title_{$APP->lang} AS `title` FROM `indicator_timetable` AS `t` ";
	$sql .= "LEFT JOIN `indicator` AS `i` ON i.id = t.indicator_id ";
	$sql .= "WHERE i.on_home = 1 AND t.year = {$year} AND t.month = {$month} AND i.period=0 ";
	$sql .= "ORDER BY i.ord ";
	
	$array['indicators'] = DBW::getArrayOfAssoc($sql);
	$dd = &$APP->date_i18n;
	//******************************************************
	$res_gross = BL::getLastTimetableGrossDate();	
	$year_gross = $array['year'] = $res_gross['year'];
	$month_gross = $array['month'] = $res_gross['month'];
	// Getting gross records for main page
	$sql = "SELECT t.*, i.id AS `id`, i.title_{$APP->lang} AS `title` FROM `indicator_timetable` AS `t` ";
	$sql .= "LEFT JOIN `indicator` AS `i` ON i.id = t.indicator_id ";
	$sql .= "WHERE i.on_home = 1 AND t.year = {$year_gross} AND i.period=1 ";
	$sql .= ($month == '13') ? "AND t.month = {$month_gross}-'1' " : "AND t.month = {$month_gross} ";
	$sql .= "ORDER BY i.ord ";
	$array['gross'] = DBW::getArrayOfAssoc($sql); 
	// Table Labels
	$array['label1'] = $dd['M'][$month].' '.$year; //��������� 25 ������� 2011
	$month_gross=='13' ? $array['label_gross1'] = $dd['K'][$month_gross-1].' '.$year_gross :$array['label_gross1'] = $dd['K'][$month_gross].' '.$year_gross;
	
	$id = $array['id'] = $APP->httpVar('id');
	$sql = "SELECT t.*, i.id AS '01001', t.month AS `month`, i.title_{$APP->lang} AS `title`, i.is_main AS `is_main` FROM `indicator_timetable` AS `t` ";
	$sql .= "LEFT JOIN `indicator` AS `i` ON i.id = t.indicator_id  WHERE `id`='01001' ";
	$sql .= "AND i.id = '01001' ";
	$sql .= "AND t.month = '13' ";
	$sql .= "ORDER BY t.year ASC";
	$result = mysql_query($sql); 
	@$array['ttitle'] = mysql_result($result,0,4);
	$array['timetable'] = DBW::getArrayOfAssoc($sql);
?>